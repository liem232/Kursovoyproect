const express = require('express');
const router = express.Router();
const { authMiddleware, permit } = require('../middleware/auth');
const { Order, User, Role } = require('../models');

router.use(authMiddleware);
router.use(permit('admin'));

router.get('/orders', async (req, res) => {
  try {
    const orders = await Order.findAll({ include: User });
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.put('/orders/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const order = await Order.findByPk(req.params.id);
    if (!order) return res.status(404).json({ error: 'order not found' });

    order.status = status;
    await order.save();
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// assign manager to order
router.put('/orders/:id/assign', async (req, res) => {
  try {
    const { managerId } = req.body;
    const order = await Order.findByPk(req.params.id);
    if (!order) return res.status(404).json({ error: 'order not found' });
    order.managerId = managerId;
    await order.save();
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.get('/users', async (req, res) => {
  try {
    const users = await User.findAll({ include: Role });
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

module.exports = router;
