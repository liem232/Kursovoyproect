const { Sequelize } = require('sequelize');
const config = require('../config/config').db;

const sequelize = new Sequelize({
  dialect: config.dialect,
  storage: config.storage,
  logging: config.logging
});

const Role = require('./role')(sequelize);
const User = require('./user')(sequelize);
const Category = require('./category')(sequelize);
const Product = require('./product')(sequelize);
const Order = require('./order')(sequelize);
const OrderItem = require('./orderItem')(sequelize);
const ChatMessage = require('./chatMessage')(sequelize);


// relations
Role.hasMany(User, { foreignKey: 'roleId' });
User.belongsTo(Role, { foreignKey: 'roleId' });

Category.hasMany(Product, { foreignKey: 'categoryId' });
Product.belongsTo(Category, { foreignKey: 'categoryId' });

User.hasMany(Order, { foreignKey: 'userId' });
Order.belongsTo(User, { foreignKey: 'userId' });

Order.hasMany(OrderItem, { foreignKey: 'orderId' });
OrderItem.belongsTo(Order, { foreignKey: 'orderId' });

Product.hasMany(OrderItem, { foreignKey: 'productId' });
OrderItem.belongsTo(Product, { foreignKey: 'productId' });

// chat relations
Order.hasMany(ChatMessage, { foreignKey: 'orderId' });
ChatMessage.belongsTo(Order, { foreignKey: 'orderId' });
User.hasMany(ChatMessage, { foreignKey: 'fromUserId' });
ChatMessage.belongsTo(User, { foreignKey: 'fromUserId' });

module.exports = { sequelize, Role, User, Category, Product, Order, OrderItem, ChatMessage };
