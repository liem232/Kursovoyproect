const express = require('express');
const { authMiddleware } = require('../middleware/auth');
const { Order, OrderItem, Product } = require('../models');

const router = express.Router();
router.use(authMiddleware);

router.post('/', async (req, res) => {
  try {
    const { items, address, phone, name, email } = req.body;
    if(!items || !Array.isArray(items)) return res.status(400).json({ error:'items required' });
    let total = 0;
    const order = await Order.create({ userId: req.user.id, status: 'new', address, phone: phone || null, customerName: name || null, email: email || null, total: 0 });
    for(const it of items){
      const product = await Product.findByPk(it.productId);
      const price = product ? product.price : 0;
      await OrderItem.create({ orderId: order.id, productId: it.productId, quantity: it.quantity, price });
      total += price * (it.quantity || 1);
    }
    order.total = total;
    await order.save();
    res.json(order);
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.get('/', async (req, res) => {
  try {
    // return orders with items and product info
    const orders = await Order.findAll({ where: { userId: req.user.id } });
    const out = [];
    for(const o of orders){
      const items = await OrderItem.findAll({ where: { orderId: o.id } });
      const detailed = [];
      for(const it of items){
        const p = await Product.findByPk(it.productId);
        detailed.push({ id: it.id, productId: it.productId, title: p ? p.title : '—', quantity: it.quantity, price: it.price });
      }
      out.push({ id: o.id, userId: o.userId, status: o.status, total: o.total, address: o.address, phone: o.phone, customerName: o.customerName, email: o.email, items: detailed, managerId: o.managerId, createdAt: o.createdAt });
    }
    res.json(out);
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

module.exports = router;
