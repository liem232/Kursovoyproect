const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { ChatMessage, Order, User, Role } = require('../models');
const jwt = require('jsonwebtoken');
const config = require('../config/config');

async function tryGetUser(req){
  const header = req.headers.authorization || '';
  const token = header.split(' ')[1];
  if(!token) return null;
  try{
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await User.findByPk(decoded.id);
    if(!user) return null;
    const role = await Role.findByPk(user.roleId);
    user.roleName = role ? role.name : null;
    return user;
  } catch(e){ return null; }
}

// get messages for an order - only order owner or assigned manager can view
// Global (pre-sales) chat - public. Admins are not shown messages in frontend, but messages are stored here.
router.get('/global/list', async (req, res) => {
  try{
    const msgsRaw = await ChatMessage.findAll({ where: { orderId: null }, order: [['createdAt','ASC']], include: [{ model: User, attributes: ['id','name','email'], include: [{ model: Role, attributes: ['name'] }] }] });
    const msgs = msgsRaw.map(m=>{
      let name = null;
      if(m.User){
        if(m.User.name) name = m.User.name;
        else if(m.User.Role && m.User.Role.name === 'manager') name = 'manager';
        else name = m.User.email || (`User#${m.fromUserId}`);
      }
      return { id: m.id, text: m.text, fromUserId: m.fromUserId, fromUserName: name, createdAt: m.createdAt };
    });
    res.json(msgs);
  } catch(err){ console.error(err); res.status(500).json({ error: 'server error' }); }
});

router.post('/global', async (req, res) => {
  try{
    const { text, name, email } = req.body;
    if(!text) return res.status(400).json({ error:'text required' });
    // determine if authenticated
    const user = await tryGetUser(req);
    console.log('[chat:global:post] authHeader=', !!req.headers.authorization, 'user=', user ? { id: user.id, role: user.roleName, email: user.email } : null);
    if(user && user.roleName === 'admin') return res.status(403).json({ error: 'forbidden' });
    const created = await ChatMessage.create({ orderId: null, fromUserId: user ? user.id : null, text });
    // return enriched message with author name
    const full = await ChatMessage.findByPk(created.id, { include: [{ model: User, attributes: ['id','name','email'], include: [{ model: Role, attributes: ['name'] }] }] });
    let nameOut = null;
    if(full.User){ if(full.User.name) nameOut = full.User.name; else if(full.User.Role && full.User.Role.name === 'manager') nameOut = 'manager'; else nameOut = full.User.email || (`User#${full.fromUserId}`); }
    res.json({ id: full.id, text: full.text, fromUserId: full.fromUserId, fromUserName: nameOut, createdAt: full.createdAt });
  } catch(err){ console.error(err); res.status(500).json({ error: 'server error' }); }
});

// get messages for an order - only order owner or assigned manager can view
router.get('/:orderId', authMiddleware, async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.orderId);
    if(!order) return res.status(404).json({ error: 'order not found' });
    const role = req.userRole;
    // debug logging
    console.log('[chat:get] userId=', req.user.id, 'role=', role, 'order.userId=', order.userId, 'order.managerId=', order.managerId);
    // admin should not access chats
    if(role === 'admin') return res.status(403).json({ error: 'forbidden', reason: 'admin not allowed' });
    // owners can view their orders; managers can view if assigned OR if order is unassigned (so they can pickup)
    if(role === 'manager'){
      if(req.user.id !== order.managerId && order.managerId) return res.status(403).json({ error: 'forbidden', reason: 'not assigned manager', reqUserId: req.user.id, orderUserId: order.userId, orderManagerId: order.managerId });
    } else {
      if(req.user.id !== order.userId) return res.status(403).json({ error: 'forbidden', reason: 'not owner', reqUserId: req.user.id, orderUserId: order.userId, orderManagerId: order.managerId });
    }
    const msgsRaw = await ChatMessage.findAll({ where: { orderId: order.id }, order: [['createdAt','ASC']], include: [{ model: User, attributes: ['id','name','email'], include: [{ model: Role, attributes: ['name'] }] }] });
    const msgs = msgsRaw.map(m=>{
      let name = null;
      if(m.User){
        if(m.User.name) name = m.User.name;
        else if(m.User.Role && m.User.Role.name === 'manager') name = 'manager';
        else name = m.User.email || (`User#${m.fromUserId}`);
      }
      return { id: m.id, text: m.text, fromUserId: m.fromUserId, fromUserName: name, createdAt: m.createdAt };
    });
    res.json({ messages: msgs, managerId: order.managerId || null });
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// post message for order - only owner or assigned manager can post (admin blocked)
router.post('/:orderId', authMiddleware, async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.orderId);
    if(!order) return res.status(404).json({ error: 'order not found' });
    const role = req.userRole;
    console.log('[chat:post] userId=', req.user.id, 'role=', role, 'order.userId=', order.userId, 'order.managerId=', order.managerId);
    if(role === 'admin') return res.status(403).json({ error: 'forbidden', reason: 'admin not allowed' });
    // allow posting: owners always, managers if assigned or unassigned (they will be auto-assigned below)
    if(role === 'manager'){
      // ok if manager assigned or unassigned
    } else {
      if(req.user.id !== order.userId) return res.status(403).json({ error: 'forbidden', reason: 'not owner', reqUserId: req.user.id, orderUserId: order.userId, orderManagerId: order.managerId });
    }
    const { text } = req.body;
    if(!text) return res.status(400).json({ error: 'text required' });
    // if order has no manager assigned yet and the author is the owner, auto-assign a manager (first available)
    if(!order.managerId && req.user.id === order.userId){
      const { User, Role } = require('../models');
      const mgrRole = await Role.findOne({ where: { name: 'manager' } });
      if(mgrRole){
        const mgr = await User.findOne({ where: { roleId: mgrRole.id } });
        if(mgr) { order.managerId = mgr.id; await order.save(); }
      }
    }
    // if order has no manager and the author is a manager, assign them as manager
    if(!order.managerId && req.userRole === 'manager'){
      order.managerId = req.user.id;
      await order.save();
    }
    const m = await ChatMessage.create({ orderId: order.id, fromUserId: req.user.id, text });
    res.json(m);
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});


module.exports = router;

