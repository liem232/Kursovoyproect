const jwt = require('jsonwebtoken');
const config = require('../config/config');
const { User, Role } = require('../models');

async function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.split(" ")[1];
  if (!token) return res.status(401).json({ error: "no token" });

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await User.findByPk(decoded.id);
    if(!user) return res.status(401).json({ error: "invalid token" });
    req.user = user;
    // attach role name for convenience
    const role = await Role.findByPk(user.roleId);
    req.userRole = role ? role.name : null;
    next();
  } catch (e) {
    res.status(401).json({ error: "invalid token" });
  }
}

function permit(...roles) {
  return async (req, res, next) => {
    const role = await Role.findByPk(req.user.roleId);
    if (!role) return res.status(403).json({ error: "role not found" });
    if (!roles.includes(role.name)) return res.status(403).json({ error: "forbidden" });
    next();
  };
}

module.exports = { authMiddleware, permit };
