module.exports = {
  jwtSecret: "super_secret_key_123",
  db: {
    dialect: "sqlite",
    storage: "./data/database.sqlite",
    logging: false
  }
};
