const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const { sequelize, Role, Category, Product, User, Order } = require('./models');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static("public"));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/manager', require('./routes/manager'));
app.use('/api/chat', require('./routes/chat'));

app.get('/api/ping', (req, res) => res.json({ ok: true }));

async function init() {
  await sequelize.sync({ alter: true });

  const roles = await Role.findAll();
  if (roles.length === 0) {
    await Role.bulkCreate([
      { name: "guest" },
      { name: "user" },
      { name: "manager" },
      { name: "admin" }
    ]);
    console.log('Seeded roles');
  }

  // seed categories and generic products "товар1" ... "товар8"
  const cats = await Category.findAll();
  if (cats.length === 0) {
    const electronics = await Category.create({ name: "Electronics" });
    const home = await Category.create({ name: "Home" });
    const books = await Category.create({ name: "Books" });
    const generic = [electronics, home, books];
    const sample = [
      { title: "Товар 1", description: "Универсальный товар 1", price: 19.90, categoryId: electronics.id },
      { title: "Товар 2", description: "Универсальный товар 2", price: 29.50, categoryId: electronics.id },
      { title: "Товар 3", description: "Универсальный товар 3", price: 9.99, categoryId: books.id },
      { title: "Товар 4", description: "Универсальный товар 4", price: 49.00, categoryId: home.id },
      { title: "Товар 5", description: "Универсальный товар 5", price: 99.99, categoryId: electronics.id },
      { title: "Товар 6", description: "Универсальный товар 6", price: 5.00, categoryId: books.id },
      { title: "Товар 7", description: "Универсальный товар 7", price: 150.00, categoryId: home.id },
      { title: "Товар 8", description: "Универсальный товар 8", price: 250.00, categoryId: electronics.id }
    ];
    await Product.bulkCreate(sample);
    console.log('Seeded categories & products');
  }

  // seed admin and manager users with known credentials if not present
  const users = await User.findAll();
  if(users.length === 0){
    const adminRole = await Role.findOne({ where: { name: 'admin' }});
    const managerRole = await Role.findOne({ where: { name: 'manager' }});
    const userRole = await Role.findOne({ where: { name: 'user' }});
    const now = new Date().toISOString();
    const adminPass = await bcrypt.hash('admin123', 10);
    const managerPass = await bcrypt.hash('manager123', 10);
    const userPass = await bcrypt.hash('user123', 10);
    await User.create({ email: 'admin@example.com', password: adminPass, name: 'Администратор', roleId: adminRole.id });
    await User.create({ email: 'manager@example.com', password: managerPass, name: 'Менеджер', roleId: managerRole.id });
    await User.create({ email: 'user@example.com', password: userPass, name: 'Пользователь', roleId: userRole.id });
    console.log('Seeded users: admin@example.com/admin123, manager@example.com/manager123, user@example.com/user123');
  }

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log("Server started at http://localhost:" + PORT));
}

init().catch(err => { console.error(err); process.exit(1); });
