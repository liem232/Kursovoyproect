const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const { User, Role } = require('../models');

const router = express.Router();

const { authMiddleware } = require('../middleware/auth');

router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if(!email || !password) return res.status(400).json({ error: 'email and password required' });
    const exists = await User.findOne({ where: { email }});
    if(exists) return res.status(400).json({ error:'user exists' });
    const hash = await bcrypt.hash(password, 10);
    const userRole = await Role.findOne({ where: { name: 'user' }});
    const user = await User.create({ email, password: hash, name, roleId: userRole ? userRole.id : 2 });
    const token = jwt.sign({ id: user.id }, config.jwtSecret, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, roleId: user.roleId }});
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email }});
    if(!user) return res.status(400).json({ error: 'invalid credentials' });
    const ok = await bcrypt.compare(password, user.password);
    if(!ok) return res.status(400).json({ error: 'invalid credentials' });
    const token = jwt.sign({ id: user.id }, config.jwtSecret, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, roleId: user.roleId }});
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.get('/me', authMiddleware, async (req, res) => {
  const u = req.user;
  // include role name for frontend convenience
  const Role = require('../models').Role;
  const role = await Role.findByPk(u.roleId);
  res.json({ id: u.id, email: u.email, name: u.name, roleId: u.roleId, roleName: role ? role.name : null });
});

module.exports = router;

