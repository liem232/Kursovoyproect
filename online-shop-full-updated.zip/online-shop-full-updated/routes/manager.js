const express = require('express');
const router = express.Router();
const { authMiddleware, permit } = require('../middleware/auth');
const { Order, User, OrderItem, Product } = require('../models');

router.use(authMiddleware);
router.use(permit('manager', 'admin'));

router.get('/orders', async (req, res) => {
  try {
    // return new orders and orders assigned to this manager
    const orders = await Order.findAll({
      include: [ User, { model: OrderItem, include: [ Product ] } ]
    });
    // filter in JS to avoid adding sequelize Op dependency
    const filtered = orders.filter(o => o.status === 'new' || o.managerId === req.user.id);
    return res.json(filtered.map(o => o.toJSON()));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

router.put('/orders/:id/processing', async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.id);
    if (!order) return res.status(404).json({ error: 'order not found' });

    order.status = 'processing';
    await order.save();
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// return users with registration date and orders count
router.get('/users', async (req, res) => {
  try {
    const users = await User.findAll();
    const out = [];
    for(const u of users){
      const orders = await Order.findAll({ where: { userId: u.id }});
      out.push({ id: u.id, email: u.email, name: u.name, createdAt: u.createdAt, orders });
    }
    res.json(out);
  } catch(err){
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

module.exports = router;
