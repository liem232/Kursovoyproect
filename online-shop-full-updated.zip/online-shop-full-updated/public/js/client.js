function getCartItems(){
  return JSON.parse(localStorage.getItem('cart') || '[]');
}
function saveCart(items){
  localStorage.setItem('cart', JSON.stringify(items));
}
function notify(message, type='info'){
  let el = document.getElementById('notify');
  if(!el){
    el = document.createElement('div');
    el.id = 'notify';
    el.style.position = 'fixed';
    el.style.top = '20px';
    el.style.right = '20px';
    el.style.zIndex = 9999;
    document.body.appendChild(el);
  }
  const item = document.createElement('div');
  item.className = 'notify ' + type;
  item.innerText = message;
  item.style.marginTop = '8px';
  item.style.padding = '10px 14px';
  item.style.borderRadius = '6px';
  item.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15)';
  item.style.background = type === 'error' ? '#ffdddd' : '#ddffdd';
  el.appendChild(item);
  setTimeout(()=> item.remove(), 4000);
}
function addToCart(id, title, price){
  const items = getCartItems();
  const idx = items.findIndex(i => i.id === id);
  if(idx >= 0) items[idx].quantity += 1;
  else items.push({ id, title, price, quantity:1 });
  saveCart(items);
  renderCart();
  renderHeader();
  notify('Товар добавлен в корзину');
}
function removeFromCart(id){
  const items = getCartItems().filter(i => i.id !== id);
  saveCart(items);
  renderCart();
  renderHeader();
  notify('Товар удалён из корзины');
}
function clearCart(){
  localStorage.removeItem('cart');
  renderCart();
  renderHeader();
}
function renderCart(){
  const c = document.getElementById('cart');
  if(!c) return;
  const items = getCartItems();
  if(items.length === 0){
    c.innerHTML = '<p class="empty">Корзина пуста</p>';
    document.getElementById('checkoutBtn')?.setAttribute('disabled','disabled');
    return;
  }
  document.getElementById('checkoutBtn')?.removeAttribute('disabled');
  let html = '<table class="cart-table"><thead><tr><th>Товар</th><th>Цена</th><th>Кол-во</th><th>Сумма</th><th></th></tr></thead><tbody>';
  let total = 0;
  for(const it of items){
    const sum = (it.price * it.quantity);
    total += sum;
    html += `<tr>
      <td>${it.title}</td>
      <td>${it.price.toFixed(2)} ₽</td>
      <td><button onclick="changeQuantity(${it.id}, ${it.quantity - 1})">-</button> <span style="margin:0 8px">${it.quantity}</span> <button onclick="changeQuantity(${it.id}, ${it.quantity + 1})">+</button></td>
      <td>${sum.toFixed(2)} ₽</td>
      <td><button class="small" onclick="removeFromCart(${it.id})">Удалить</button></td>
    </tr>`;
  }
  html += `</tbody></table><div class="cart-total">Итого: <strong>${total.toFixed(2)} ₽</strong></div>`;
  c.innerHTML = html;
}

function changeQuantity(id, newQty){
  if(newQty <= 0) return removeFromCart(id);
  const items = getCartItems();
  const idx = items.findIndex(i=>i.id === id);
  if(idx >= 0){ items[idx].quantity = newQty; saveCart(items); renderCart(); renderHeader(); }
}

// Chat in bottom-left (server-backed when authenticated)
async function getChat(orderId){
  const token = localStorage.getItem('token');
  if(token && orderId){
    try{
      const res = await fetch('/api/chat/' + orderId, { headers: { Authorization: 'Bearer ' + token } });
      if(res.ok){
        const data = await res.json();
        // support two shapes: legacy array or { messages, managerId }
        if(Array.isArray(data)) return data;
        if(data && data.messages) return data.messages;
        return data;
      }
      const body = await res.text().catch(()=>'');
      return { error:true, status: res.status, body };
    } catch (e){ return []; }
  }
  // fallback to localStorage per-order chats
  const chats = JSON.parse(localStorage.getItem('chats') || '{}');
  return chats[orderId] || [];
}

async function sendChatMessage(orderId, text){
  const token = localStorage.getItem('token');
  if(token && orderId){
    try{
      const res = await fetch('/api/chat/' + orderId, { method:'POST', headers: { 'Content-Type':'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ text }) });
      if(res.ok){
        if(window.chatWidgetRender) window.chatWidgetRender();
        return;
      }
      const errBody = await res.text().catch(()=>'');
      notify('Ошибка отправки: ' + (errBody || res.status), 'error');
      console.error('sendChatMessage failed', res.status, errBody);
    } catch(e){ }
  }
  // fallback localStorage
  const chats = JSON.parse(localStorage.getItem('chats') || '{}');
  if(!chats[orderId]) chats[orderId] = [];
  chats[orderId].push({ from: 'guest', text, ts: new Date().toISOString() });
  localStorage.setItem('chats', JSON.stringify(chats));
  if(window.chatWidgetRender) window.chatWidgetRender();
}

// Chat widget DOM creation (show on all pages for non-admin/non-manager users)
async function initChatWidget(){
  if(document.getElementById('chat-widget')) return;
  let user = JSON.parse(localStorage.getItem('user') || 'null');
  const token = localStorage.getItem('token');
  if(!user && token){
    try{
      const res = await fetch('/api/auth/me', { headers: { Authorization: 'Bearer ' + token } });
      if(res.ok){ user = await res.json(); localStorage.setItem('user', JSON.stringify(user)); }
    } catch(e){}
  }
  // hide chat for admin and manager (they use dashboard)
  if(user && (user.roleName === 'admin' || user.roleName === 'manager')) return;
  const wrapper = document.createElement('div');
  wrapper.id = 'chat-widget';
  wrapper.innerHTML = `
    <div id="chat-head">Чат</div>
    <div style="display:flex;gap:8px;padding:8px;align-items:center">
      <select id="chat-type" title="Выберите тип чата" aria-label="Тип чата" style="padding:6px;border-radius:6px;border:1px solid #ddd">
        <option value="order">По заказу</option>
        <option value="global">Предпродажа</option>
      </select>
      <select id="chat-order-select" title="Выберите заказ" aria-label="Заказ для чата" style="margin-left:4px;padding:6px;border-radius:6px;border:1px solid #ddd"></select>
    </div>
    <div id="chat-body"></div>
    <form id="chat-send" style="display:flex;margin-top:8px;">
      <input id="chat-input" placeholder="Сообщение..." style="flex:1;padding:6px;border-radius:4px;border:1px solid #ccc"/>
      <button type="submit" style="margin-left:6px;">Отправить</button>
    </form>
  `;
  document.body.appendChild(wrapper);
  wrapper.style.position = 'fixed';
  wrapper.style.left = '20px';
  wrapper.style.bottom = '20px';
  wrapper.style.width = '360px';
  wrapper.style.background = '#fff';
  wrapper.style.border = '1px solid #ddd';
  wrapper.style.borderRadius = '8px';
  wrapper.style.boxShadow = '0 6px 18px rgba(0,0,0,0.12)';
  wrapper.style.zIndex = 9998;
  wrapper.style.overflow = 'hidden';
  wrapper.style.display = 'flex';
  wrapper.style.flexDirection = 'column';
  wrapper.querySelector('#chat-head').style.padding = '8px';
  wrapper.querySelector('#chat-head').style.background = '#f5f5f5';
  wrapper.querySelector('#chat-head').style.fontWeight = '600';
  wrapper.querySelector('#chat-body').style.padding = '8px';
  wrapper.querySelector('#chat-body').style.height = '220px';
  wrapper.querySelector('#chat-body').style.overflow = 'auto';

  const form = wrapper.querySelector('#chat-send');
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const input = document.getElementById('chat-input');
    const type = document.getElementById('chat-type').value;
    const select = document.getElementById('chat-order-select');
    const orderId = select.value;
    if(!input.value) return;
    if(type === 'global'){
      await sendGlobalChat(input.value);
    } else {
      await sendChatMessage(orderId, input.value);
    }
    input.value = '';
    renderChatWidget();
  });

  // re-render when user switches chat type or selects another order
  const typeSel = wrapper.querySelector('#chat-type');
  const orderSel = wrapper.querySelector('#chat-order-select');
  if(typeSel) typeSel.addEventListener('change', () => { renderChatWidget(); });
  if(orderSel) orderSel.addEventListener('change', () => { renderChatWidget(); });

  window.chatWidgetRender = renderChatWidget;
  renderChatWidget();
}

async function renderChatWidget(){
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const body = document.getElementById('chat-body');
  if(!body) return;
  const select = document.getElementById('chat-order-select');
  // populate orders select for logged-in users
  if(select) select.innerHTML = '';
  if(user && localStorage.getItem('token')){
    try{
      const res = await fetch('/api/orders', { headers: { Authorization: 'Bearer ' + localStorage.getItem('token') } });
      if(res.ok){
        const orders = await res.json();
        console.log('[chat] user orders:', orders.map(o=>({ id:o.id, userId: o.userId, status: o.status })));
        orders.forEach(o=>{ if(select){ const opt = document.createElement('option'); opt.value = o.id; opt.innerText = `Заказ #${o.id} — ${o.status}`; opt.dataset.userid = o.userId; select.appendChild(opt); } });
      }
    } catch(e){}
  }
  const type = document.getElementById('chat-type').value;
  if(type === 'global'){
    // load global chat
    try{
      const r = await fetch('/api/chat/global/list');
      if(r.ok){ const msgs = await r.json(); body.innerHTML = msgs.map(m=>{ const by = m.fromUserName || (m.fromUserId ? ('User#'+m.fromUserId) : 'Гость'); return `<div style="margin-bottom:6px"><strong>${by}:</strong> ${m.text}</div>`; }).join('') || '<div><em>Нет сообщений</em></div>'; }
      else body.innerHTML = '<div><em>Нет сообщений</em></div>';
    } catch(e){ body.innerHTML = '<div><em>Ошибка</em></div>'; }
  } else {
    const orderId = (select && select.value) || (select && select.options[0] ? select.options[0].value : null);
    if(!orderId){ body.innerHTML = '<div><em>Нет заказов для чата</em></div>'; return; }
    // verify ownership: option may carry data-userid (server now returns userId)
    const selectedOpt = select && select.querySelector(`option[value="${orderId}"]`);
    const optUserId = selectedOpt ? parseInt(selectedOpt.dataset.userid || '0', 10) : null;
    if(optUserId && user && optUserId !== user.id){
      body.innerHTML = `<div><em>Не доступно: выбран заказ, который не принадлежит вам</em></div>`;
      return;
    }
    const msgs = await getChat(orderId);
    if(msgs && msgs.error){
      body.innerHTML = `<div><em>Не доступно (код ${msgs.status})</em><div style="color:#999;font-size:0.9rem">${msgs.body}</div></div>`;
      return;
    }
    const uid = user ? user.id : null;
    body.innerHTML = msgs.map(m=>{
      const by = m.fromUserName || (m.fromUserId ? (m.fromUserId === uid ? 'Вы' : ('User#' + m.fromUserId)) : 'system');
      return `<div style="margin-bottom:6px"><strong>${by}:</strong> ${m.text}</div>`;
    }).join('') || '<div><em>Нет сообщений</em></div>';
  }
}

async function sendGlobalChat(text){
  try{
    const token = localStorage.getItem('token');
    const headers = { 'Content-Type': 'application/json' };
    if(token) headers.Authorization = 'Bearer ' + token;
    await fetch('/api/chat/global', { method:'POST', headers, body: JSON.stringify({ text }) });
    if(window.chatWidgetRender) window.chatWidgetRender();
  } catch(e){ console.error('sendGlobalChat failed', e); }
}

// Header: renders modern header with user and cart info
function renderHeader(){
  const container = document.querySelector('.container');
  if(!container) return;
  // remove existing injected header if any
  const existing = document.getElementById('site-header-injected');
  if(existing) existing.remove();
  // remove any original header inside container to avoid duplicates
  const oldHeaders = Array.from(container.querySelectorAll('header')).filter(h=>h.id !== 'site-header-injected');
  oldHeaders.forEach(h=>h.remove());
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const cart = getCartItems();
  const header = document.createElement('header');
  header.id = 'site-header-injected';
  header.className = 'site-header';
  header.innerHTML = `
    <div class="site-left">
      <div class="site-logo"><a href="/index.html">Shop<span class="accent">.</span></a></div>
      <div class="site-search"><input id="site-search-input" placeholder="Поиск товаров..."/></div>
    </div>
    <div class="site-right">
      <nav class="header-nav">
        <a href="/catalog.html">Каталог</a>
        ${user && user.roleName === 'manager' ? '<a href="/manager-dashboard.html">Менеджер</a>' : ''}
        ${user && user.roleName === 'admin' ? '<a href="/admin.html">Админ</a>' : ''}
        <a href="/cart.html" id="cart-link">Корзина (<span id="cart-count">${cart.reduce((s,i)=>s+i.quantity,0)}</span>)</a>
        <span id="user-area">${user ? `<a href="#" id="user-profile-link" class="user-name" title="Ваш профиль">${user.name || user.email}</a> <button id="logoutBtn" class="small">Выйти</button>` : `<a href="/login.html">Войти</a> <a href="/register.html">Регистрация</a>`}</span>
      </nav>
    </div>
  `;
  header.style.marginBottom = '18px';
  container.insertBefore(header, container.firstChild);

  const logoutBtn = document.getElementById('logoutBtn');
  if(logoutBtn){
    logoutBtn.addEventListener('click', ()=>{
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      renderHeader();
      notify('Вы вышли');
      setTimeout(()=> location.href='/index.html', 300);
    });
  }

  // profile link: navigate according to role without user typing address
  const profileLink = document.getElementById('user-profile-link');
  if(profileLink){
    profileLink.addEventListener('click', (e)=>{
      e.preventDefault();
      const u = JSON.parse(localStorage.getItem('user') || 'null');
      const role = u ? u.roleName : null;
      if(role === 'manager') location.href = '/manager-dashboard.html';
      else if(role === 'admin') location.href = '/admin.html';
      else location.href = '/user-dashboard.html';
    });
  }

  const searchInput = document.getElementById('site-search-input');
  if(searchInput){
    searchInput.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        const q = searchInput.value.trim().toLowerCase();
        const list = Array.from(document.querySelectorAll('.card'));
        // naive client-side filter: hide cards not matching
        list.forEach(card=>{
          const t = (card.querySelector('h3')?.innerText||'').toLowerCase();
          card.style.display = t.includes(q) ? '' : 'none';
        });
      }
    });
  }
}

function renderFooter(){
  const container = document.querySelector('.container');
  if(!container) return;
  // remove existing footer
  const existing = document.getElementById('site-footer-injected');
  if(existing) existing.remove();
  const footer = document.createElement('footer');
  footer.id = 'site-footer-injected';
  footer.style.marginTop = '28px';
  footer.style.padding = '18px';
  footer.style.textAlign = 'center';
  footer.style.color = '#6b7280';
  footer.innerHTML = `© ${new Date().getFullYear()} Shop. Все права защищены. <span style="margin-left:10px">Поддержка: <a href="mailto:support@example.com">support@example.com</a></span>`;
  container.appendChild(footer);
}

// initialize chat widget on DOM ready
document.addEventListener('DOMContentLoaded', async ()=>{
  await initChatWidget();
  renderCart();
  renderHeader();
  renderFooter();
});
