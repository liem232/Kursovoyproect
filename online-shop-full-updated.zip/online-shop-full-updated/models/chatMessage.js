const { DataTypes } = require('sequelize');
module.exports = (sequelize) => sequelize.define('ChatMessage', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  orderId: DataTypes.INTEGER,
  fromUserId: DataTypes.INTEGER,
  text: DataTypes.TEXT
});
